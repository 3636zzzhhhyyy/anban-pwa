// 初始化粒子效果
document.addEventListener('DOMContentLoaded', function() {
    // 检查是否加载了particles.js
    if (typeof particlesJS !== 'undefined') {
        // 适应新背景的粒子效果
        particlesJS('particles-js', {
            particles: {
                number: { value: 100, density: { enable: true, value_area: 500 } },
                color: { value: ["#ffffff", "#a8edea", "#fed6e3"] },
                shape: { type: "circle" },
                opacity: { value: 0.6, random: true },
                size: { value: 3, random: true },
                line_linked: { 
                    enable: true, 
                    distance: 120, 
                    color: "#ffffff", 
                    opacity: 0.3, 
                    width: 1 
                },
                move: { 
                    enable: true, 
                    speed: 1.2, 
                    direction: "none", 
                    random: true, 
                    straight: false, 
                    out_mode: "bounce" 
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "repulse" },
                    onclick: { enable: true, mode: "push" }
                }
            }
        });

        // 滑动导航功能
        const sections = document.querySelectorAll('section');
        const navLinks = document.querySelectorAll('.slider-nav a');
        
        function updateSliderNav() {
            let index = sections.length;
            
            while(--index && window.scrollY + 100 < sections[index].offsetTop) {}
            
            navLinks.forEach(link => link.classList.remove('active'));
            navLinks[index].classList.add('active');
        }
        
        navLinks.forEach((link, index) => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                window.scrollTo({
                    top: sections[index].offsetTop,
                    behavior: 'smooth'
                });
            });
        });
        
        window.addEventListener('scroll', updateSliderNav);
        updateSliderNav();
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "grab" },
                    onclick: { enable: true, mode: "push" }
                }
            }
        });
    } else {
        console.error('particles.js未正确加载');
    }

    // 添加滚动动画
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.scroll-animate');
        elements.forEach(el => {
            const elTop = el.getBoundingClientRect().top;
            if (elTop < window.innerHeight - 100) {
                el.classList.add('animated');
            }
        });
    };

    // 初始化页面加载时的动画
    window.addEventListener('load', () => {
        // 触发初始动画
        const fadeElements = document.querySelectorAll('.fade-in');
        fadeElements.forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = 1;
            }, index * 300);
        });

        // 初始滚动动画检查
        animateOnScroll();
    });

    // 滚动事件监听
    window.addEventListener('scroll', animateOnScroll);

    // 交互元素效果
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('mouseenter', () => {
            btn.style.transform = 'translateY(-2px)';
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.transform = 'translateY(0)';
        });
    });

    // 卡片悬停效果
    const cards = document.querySelectorAll('.feature-card, .tech-item, .solution-card, .member-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-5px)';
            card.style.boxShadow = '0 10px 20px rgba(0,0,0,0.1)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
            card.style.boxShadow = 'none';
        });
    });

    // 表单交互效果
    const formInputs = document.querySelectorAll('.form-group input, .form-group textarea');
    formInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    });
});